//! Workflow and run-history database.
//!
//! Moved from commands/workflow.rs so the server binary can use it without
//! depending on Tauri. The Tauri app imports this from flowo_engine::db.

use r2d2::Pool;
use r2d2_sqlite::SqliteConnectionManager;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;


mod workflow_db;
mod run_history;
mod scheduler_db;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RunRecord {
    pub id:            String,
    pub workflow_id:   String,
    pub workflow_name: String,
    pub ran_at:        String,
    pub success:       bool,
    pub duration_ms:   i64,
    pub result_json:   String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VersionRow {
    pub id:          String,
    pub workflow_id: String,
    pub message:     Option<String>,
    pub created_at:  String,
}

pub(super) fn row_to_run(row: &rusqlite::Row) -> rusqlite::Result<RunRecord> {
    Ok(RunRecord {
        id:            row.get(0)?,
        workflow_id:   row.get(1)?,
        workflow_name: row.get(2)?,
        ran_at:        row.get(3)?,
        success:       row.get::<_, i64>(4)? != 0,
        duration_ms:   row.get(5)?,
        result_json:   row.get(6)?,
    })
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkflowSummary {
    pub id:         String,
    pub name:       String,
    pub updated_at: String,
}

pub struct WorkflowDb {
    pub(super) pool:          Pool<SqliteConnectionManager>,
    pub(super) history_limit: i64,
}

impl WorkflowDb {
    /// Current schema version. Increment this and add a `migrate_vN` block
    /// in `run_migrations` for every schema change.
    pub(super) const SCHEMA_VERSION: i64 = 1;

    pub fn open(path: &PathBuf, pool_size: usize) -> Result<Self, String> {
        let manager = SqliteConnectionManager::file(path)
            .with_init(|conn| {
                conn.execute_batch(
                    "PRAGMA busy_timeout=5000;
                     PRAGMA journal_mode=WAL;
                     PRAGMA synchronous=NORMAL;
                     PRAGMA cache_size=-8000;
                     PRAGMA temp_store=MEMORY;
                     PRAGMA foreign_keys=ON;"
                )
            });

        let pool = Pool::builder()
            .max_size(pool_size.max(1) as u32)
            .build(manager)
            .map_err(|e| e.to_string())?;

        {
            let conn = pool.get().map_err(|e| e.to_string())?;
            Self::run_migrations(&conn)?;
        }

        let history_limit = {
            let conn = pool.get().map_err(|e| e.to_string())?;
            let result = conn.query_row(
                "SELECT value FROM settings WHERE key = 'run_history_limit'",
                [],
                |row| row.get::<_, String>(0),
            );
            match result {
                Ok(v) => v.parse::<i64>().unwrap_or(500),
                Err(rusqlite::Error::QueryReturnedNoRows) => 500,
                Err(e) => return Err(e.to_string()),
            }
        };

        Ok(Self { pool, history_limit })
    }

    fn run_migrations(conn: &rusqlite::Connection) -> Result<(), String> {
        let current_version: i64 = conn
            .query_row("PRAGMA user_version", [], |row| row.get(0))
            .map_err(|e| e.to_string())?;

        if current_version >= Self::SCHEMA_VERSION {
            return Ok(());
        }

        if current_version < 1 {
            Self::migrate_v1(conn)?;
        }

        Ok(())
    }

    /// Version 1 — initial release baseline.
    /// All tables created with IF NOT EXISTS so this is safe to run against a
    /// pre-migration database that already has some or all tables present.
    fn migrate_v1(conn: &rusqlite::Connection) -> Result<(), String> {
        conn.execute_batch("
            BEGIN;
            CREATE TABLE IF NOT EXISTS workflows (
                id          TEXT PRIMARY KEY,
                name        TEXT NOT NULL,
                json        TEXT NOT NULL,
                created_at  TEXT NOT NULL,
                updated_at  TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS scheduled_jobs (
                workflow_id    TEXT PRIMARY KEY,
                workflow_name  TEXT NOT NULL,
                trigger_kind   TEXT NOT NULL,
                status         TEXT NOT NULL DEFAULT 'active',
                always_on      INTEGER NOT NULL DEFAULT 0,
                run_count      INTEGER NOT NULL DEFAULT 0,
                last_run_at    TEXT,
                next_run_at    TEXT,
                last_error     TEXT,
                created_at     TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS run_history (
                id              TEXT PRIMARY KEY,
                workflow_id     TEXT NOT NULL,
                workflow_name   TEXT NOT NULL,
                ran_at          TEXT NOT NULL,
                success         INTEGER NOT NULL,
                duration_ms     INTEGER NOT NULL,
                result_json     TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS workflow_variables (
                workflow_id   TEXT NOT NULL,
                variable_name TEXT NOT NULL,
                value_json    TEXT NOT NULL,
                updated_at    TEXT NOT NULL,
                PRIMARY KEY (workflow_id, variable_name)
            );
            CREATE TABLE IF NOT EXISTS workflow_versions (
                id          TEXT PRIMARY KEY,
                workflow_id TEXT NOT NULL,
                snapshot    TEXT NOT NULL,
                message     TEXT,
                created_at  TEXT NOT NULL,
                FOREIGN KEY (workflow_id) REFERENCES workflows(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_run_history_workflow
                ON run_history(workflow_id, ran_at DESC);
            PRAGMA user_version = 1;
            COMMIT;
        ").map_err(|e| e.to_string())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_path(tag: &str) -> PathBuf {
        let mut p = std::env::temp_dir();
        p.push(format!("flowo_db_test_{}.db", tag));
        p
    }

    fn cleanup(path: &PathBuf) {
        let _ = std::fs::remove_file(path);
        let mut wal = path.clone();
        wal.set_extension("db-wal");
        let _ = std::fs::remove_file(&wal);
        let mut shm = path.clone();
        shm.set_extension("db-shm");
        let _ = std::fs::remove_file(&shm);
    }

    #[test]
    fn test_fresh_db_schema_version() {
        let path = temp_path("fresh");
        cleanup(&path);

        let db = WorkflowDb::open(&path, 8).expect("open failed");
        let conn = db.pool.get().unwrap();
        let v: i64 = conn.query_row("PRAGMA user_version", [], |r| r.get(0)).unwrap();
        assert_eq!(v, 1);

        cleanup(&path);
    }

    #[test]
    fn test_existing_db_migrates_and_preserves_data() {
        let path = temp_path("existing");
        cleanup(&path);

        {
            let conn = rusqlite::Connection::open(&path).unwrap();
            conn.execute_batch("
                CREATE TABLE IF NOT EXISTS workflows (
                    id TEXT PRIMARY KEY, name TEXT NOT NULL,
                    json TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
                );
                INSERT INTO workflows (id, name, json, created_at, updated_at)
                VALUES ('wf-1', 'My Workflow', '{}', '2024-01-01T00:00:00Z', '2024-01-01T00:00:00Z');
            ").unwrap();
        }

        let db = WorkflowDb::open(&path, 8).expect("migration failed");

        let conn = db.pool.get().unwrap();
        let v: i64 = conn.query_row("PRAGMA user_version", [], |r| r.get(0)).unwrap();
        assert_eq!(v, 1, "must be migrated to v1");

        let count: i64 = conn
            .query_row("SELECT COUNT(*) FROM workflows", [], |r| r.get::<_, i64>(0))
            .unwrap();
        assert_eq!(count, 1, "pre-existing row must survive migration");

        cleanup(&path);
    }

    #[test]
    fn test_open_twice_is_idempotent() {
        let path = temp_path("idempotent");
        cleanup(&path);

        WorkflowDb::open(&path, 8).expect("first open failed");
        WorkflowDb::open(&path, 8).expect("second open must not fail");

        cleanup(&path);
    }
}
