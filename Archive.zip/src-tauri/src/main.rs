#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    flowo_lib::run();
}
