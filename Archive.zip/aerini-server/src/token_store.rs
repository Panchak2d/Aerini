//! SQLite-backed token registry for API mode.
//!
//! Each token is stored as a BLAKE3 keyed hash — the raw token is shown once at
//! creation time and never persisted in plaintext. The 32-byte key lives in
//! `data_dir/tokens.key` and is generated on first run.
//!
//! Scopes: `read`, `write`, `admin`.
//! - `read`  → GET endpoints
//! - `write` → POST / DELETE on workflows, credentials, scheduler
//! - `admin` → all of the above + token management (`/api/tokens`)
//!
//! An `admin`-scoped token satisfies any scope check.

use chrono::Utc;
use rand::TryRng;
use base64::Engine;
use rusqlite::{params, Connection, OptionalExtension, TransactionBehavior};
use serde::{Deserialize, Serialize};
use std::{path::Path, sync::Mutex};
use subtle::ConstantTimeEq;
use uuid::Uuid;

fn hash_token(key: &[u8; 32], raw: &str) -> String {
    blake3::keyed_hash(key, raw.as_bytes()).to_hex().to_string()
}

/// A token record returned from lookups. Does NOT contain the raw token or hash.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TokenRecord {
    pub token_id:   String,
    pub label:      String,
    pub scopes:     Vec<String>,
    pub created_at: String,
    pub expires_at: Option<String>,
}

impl TokenRecord {
    pub fn has_scope(&self, required: &str) -> bool {
        self.scopes.iter().any(|s| s == required || s == "admin")
    }
}

/// A token entry for listing — includes revocation status, still no hash.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TokenInfo {
    pub token_id:   String,
    pub label:      String,
    pub scopes:     Vec<String>,
    pub created_at: String,
    pub revoked_at: Option<String>,
    pub expires_at: Option<String>,
}

/// Outcome of [`TokenStore::acl_grant`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AclGrant {
    Granted,
    /// No token with that id, or it is revoked.
    NoActiveToken,
    /// Admin tokens ignore the ACL, so a grant would report a restriction
    /// that is never enforced.
    AdminToken,
}

/// Outcome of [`TokenStore::acl_revoke`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AclRevoke {
    Revoked,
    /// The token does not hold that grant. Nothing changed.
    NotGranted,
    /// It is the token's only grant. Removing it would leave the token with no
    /// grants, which means unrestricted, so nothing was changed.
    LastGrant,
}

pub struct TokenStore {
    conn: Mutex<Connection>,
    key:  [u8; 32],
}

impl TokenStore {
    pub fn open(path: &Path, key: [u8; 32]) -> rusqlite::Result<Self> {
        let conn = Connection::open(path)?;
        conn.execute_batch(
            "CREATE TABLE IF NOT EXISTS tokens (
                token_id   TEXT PRIMARY KEY,
                token_hash TEXT NOT NULL UNIQUE,
                label      TEXT NOT NULL,
                scopes     TEXT NOT NULL,
                created_at TEXT NOT NULL,
                revoked_at TEXT
            );
            -- Per-workflow ACL.
            -- Row presence = token is restricted to the granted workflows.
            -- Tokens with NO rows in this table are unrestricted, so the last
            -- row of a restricted token is never removed on its own;
            -- revoke_token() clears them together with the token.
            -- Admin-scoped tokens are always unrestricted regardless of this table.
            -- Note: no ON DELETE CASCADE — foreign_keys pragma is off in this db.
            -- ACL rows for revoked tokens are deleted by revoke_token().
            CREATE TABLE IF NOT EXISTS token_workflow_acl (
                token_id    TEXT NOT NULL,
                workflow_id TEXT NOT NULL,
                granted_at  TEXT NOT NULL,
                PRIMARY KEY (token_id, workflow_id)
            );",
        )?;
        // Schema migration: add expires_at to databases created before that column existed.
        let has_expires: bool = conn.query_row(
            "SELECT COUNT(*) FROM pragma_table_info('tokens') WHERE name='expires_at'",
            [],
            |row| row.get::<_, i64>(0),
        ).map(|c| c > 0).unwrap_or(false);
        if !has_expires {
            conn.execute("ALTER TABLE tokens ADD COLUMN expires_at TEXT", [])?;
        }
        Ok(Self { conn: Mutex::new(conn), key })
    }

    /// Create a new token. Returns the raw (unhashed) token string — shown once.
    /// `expires_in_secs`: optional TTL in seconds. None = non-expiring.
    /// Test-only convenience wrapper; the `/api/tokens` route calls
    /// `create_token_with_workflows` directly to also pass along ACL grants.
    #[cfg(test)]
    pub fn create_token(&self, label: &str, scopes: &[&str], expires_in_secs: Option<u64>) -> rusqlite::Result<String> {
        self.create_token_with_id(label, scopes, expires_in_secs).map(|(_, raw)| raw)
    }

    /// Same as [`create_token`](Self::create_token), also returning the new
    /// token's id — needed by callers that must act on the token immediately
    /// after creation (e.g. granting a workflow ACL) without a second lookup.
    /// Test-only; see `create_token`.
    #[cfg(test)]
    pub fn create_token_with_id(&self, label: &str, scopes: &[&str], expires_in_secs: Option<u64>) -> rusqlite::Result<(String, String)> {
        self.create_token_with_workflows(label, scopes, expires_in_secs, &[])
    }

    /// Same as [`create_token_with_id`], additionally granting ACL access
    /// to each of `workflow_ids` in the same transaction as the token row
    /// itself — a failure partway through the ACL grants rolls back the
    /// token row too, instead of leaving an orphaned, partially-scoped token
    /// behind. `create_token_with_id` is this with an empty slice.
    pub fn create_token_with_workflows(
        &self,
        label: &str,
        scopes: &[&str],
        expires_in_secs: Option<u64>,
        workflow_ids: &[String],
    ) -> rusqlite::Result<(String, String)> {
        // 32 bytes from OsRng → 256 bits of entropy, URL-safe base64 encoded.
        let mut raw_bytes = [0u8; 32];
        rand::rngs::SysRng.try_fill_bytes(&mut raw_bytes).expect("OS RNG failure");
        let raw      = base64::engine::general_purpose::URL_SAFE_NO_PAD.encode(raw_bytes);
        let token_id = Uuid::new_v4().to_string();
        let hash     = hash_token(&self.key, &raw);
        let scopes_j = serde_json::to_string(scopes).unwrap_or_else(|_| "[]".to_string());
        let now      = Utc::now();
        let now_s    = now.to_rfc3339();
        let expires_at: Option<String> = expires_in_secs.map(|secs| {
            let secs_i64 = i64::try_from(secs).unwrap_or(i64::MAX);
            (now + chrono::Duration::seconds(secs_i64)).to_rfc3339()
        });
        let mut conn = self.conn.lock().unwrap_or_else(|e| e.into_inner());
        let tx = conn.transaction()?;
        tx.execute(
            "INSERT INTO tokens (token_id, token_hash, label, scopes, created_at, expires_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
            params![token_id, hash, label, scopes_j, now_s, expires_at],
        )?;
        for wf_id in workflow_ids {
            tx.execute(
                "INSERT OR IGNORE INTO token_workflow_acl (token_id, workflow_id, granted_at)
                 VALUES (?1, ?2, ?3)",
                params![token_id, wf_id, now_s],
            )?;
        }
        tx.commit()?;
        Ok((token_id, raw))
    }

    /// Import an existing raw token (e.g. from `AERINI_TOKEN` migration).
    /// If token is already present and active, no-op.
    pub fn import_token(&self, raw: &str, label: &str, scopes: &[&str]) -> rusqlite::Result<()> {
        let hash = hash_token(&self.key, raw);
        let conn = self.conn.lock().unwrap_or_else(|e| e.into_inner());
        let count: i64 = conn.query_row(
            "SELECT COUNT(*) FROM tokens WHERE token_hash = ?1",
            params![hash],
            |row| row.get(0),
        )?;
        if count > 0 {
            return Ok(());
        }
        let token_id = Uuid::new_v4().to_string();
        let scopes_j = serde_json::to_string(scopes).unwrap_or_else(|_| "[]".to_string());
        let now      = Utc::now().to_rfc3339();
        conn.execute(
            "INSERT INTO tokens (token_id, token_hash, label, scopes, created_at)
             VALUES (?1, ?2, ?3, ?4, ?5)",
            params![token_id, hash, label, scopes_j, now],
        )?;
        Ok(())
    }

    /// Verify a raw bearer token. Returns `None` if not found, revoked, or expired.
    pub fn verify_token(&self, raw: &str) -> Option<TokenRecord> {
        let provided_hash = hash_token(&self.key, raw);
        let conn = self.conn.lock().unwrap_or_else(|e| e.into_inner());
        // Use the indexed WHERE clause so the lookup remains O(log n).
        // Then re-verify with constant-time byte comparison in-process for defense-in-depth:
        // SQLite string equality is not guaranteed constant-time, and the hash is sensitive.
        // If the hashes don't match in-process after the DB lookup, treat as not found.
        conn.query_row(
            "SELECT token_id, token_hash, label, scopes, created_at, expires_at
             FROM tokens
             WHERE token_hash = ?1
               AND revoked_at IS NULL",
            params![provided_hash],
            |row| {
                Ok((
                    row.get::<_, String>(0)?,           // token_id
                    row.get::<_, String>(1)?,           // token_hash (for ct_eq)
                    row.get::<_, String>(2)?,           // label
                    row.get::<_, String>(3)?,           // scopes
                    row.get::<_, String>(4)?,           // created_at
                    row.get::<_, Option<String>>(5)?,   // expires_at
                ))
            },
        ).ok().and_then(|(token_id, db_hash, label, scopes_j, created_at, expires_at)| {
            // In-process constant-time confirmation — guards against any SQLite
            // comparison short-circuit or timing side-channel.
            let matched: bool = db_hash.as_bytes()
                .ct_eq(provided_hash.as_bytes())
                .into();
            if !matched { return None; }
            let scopes: Vec<String> = serde_json::from_str(&scopes_j).unwrap_or_default();
            let record = TokenRecord { token_id, label, scopes, created_at, expires_at };
            if let Some(ref exp_str) = record.expires_at {
                match chrono::DateTime::parse_from_rfc3339(exp_str) {
                    Ok(exp) if Utc::now() < exp.with_timezone(&Utc) => {}
                    _ => return None,
                }
            }
            Some(record)
        })
    }

    /// Revoke a token by its `token_id`. Idempotent for an already-revoked token.
    /// Returns `false` when no token has that id.
    /// Also cleans up ACL rows for the token atomically in the same transaction.
    pub fn revoke_token(&self, token_id: &str) -> rusqlite::Result<bool> {
        let now  = Utc::now().to_rfc3339();
        let mut conn = self.conn.lock().unwrap_or_else(|e| e.into_inner());
        let tx = conn.transaction()?;
        let exists: bool = tx.query_row(
            "SELECT EXISTS(SELECT 1 FROM tokens WHERE token_id = ?1)",
            params![token_id],
            |row| row.get(0),
        )?;
        tx.execute(
            "UPDATE tokens SET revoked_at = ?1 WHERE token_id = ?2 AND revoked_at IS NULL",
            params![now, token_id],
        )?;
        tx.execute(
            "DELETE FROM token_workflow_acl WHERE token_id = ?1",
            params![token_id],
        )?;
        tx.commit()?;
        Ok(exists)
    }

    /// List all tokens (active and revoked), ordered by creation time.
    pub fn list_tokens(&self) -> rusqlite::Result<Vec<TokenInfo>> {
        let conn = self.conn.lock().unwrap_or_else(|e| e.into_inner());
        let mut stmt = conn.prepare(
            "SELECT token_id, label, scopes, created_at, revoked_at, expires_at
             FROM tokens
             ORDER BY created_at ASC",
        )?;
        let rows = stmt.query_map([], |row| {
            let scopes_j: String = row.get(2)?;
            let scopes: Vec<String> = serde_json::from_str(&scopes_j).unwrap_or_default();
            Ok(TokenInfo {
                token_id:   row.get(0)?,
                label:      row.get(1)?,
                scopes,
                created_at: row.get(3)?,
                revoked_at: row.get(4)?,
                expires_at: row.get(5)?,
            })
        })?;
        rows.collect()
    }

    /// Returns `true` if the store has no tokens at all (first-run detection).
    pub fn is_empty(&self) -> bool {
        let conn = self.conn.lock().unwrap_or_else(|e| e.into_inner());
        conn.query_row(
            "SELECT COUNT(*) FROM tokens",
            [],
            |row| row.get::<_, i64>(0),
        ).map(|c| c == 0)
         .unwrap_or(true)
    }

    // ── Per-workflow ACL ──────────────────────────────────────────────────

    /// Grant an active (not revoked), non-admin token access to a specific workflow.
    /// Once ANY ACL row exists for a token, it is restricted to those workflows only.
    /// Writes nothing unless the result is [`AclGrant::Granted`].
    /// No-op if already granted.
    pub fn acl_grant(&self, token_id: &str, workflow_id: &str) -> rusqlite::Result<AclGrant> {
        let now  = Utc::now().to_rfc3339();
        let conn = self.conn.lock().unwrap_or_else(|e| e.into_inner());
        let scopes_j: Option<String> = conn.query_row(
            "SELECT scopes FROM tokens WHERE token_id = ?1 AND revoked_at IS NULL",
            params![token_id],
            |row| row.get(0),
        ).optional()?;
        let Some(scopes_j) = scopes_j else {
            return Ok(AclGrant::NoActiveToken);
        };
        let scopes: Vec<String> = serde_json::from_str(&scopes_j).unwrap_or_default();
        if scopes.iter().any(|sc| sc == "admin") {
            return Ok(AclGrant::AdminToken);
        }
        conn.execute(
            "INSERT OR IGNORE INTO token_workflow_acl (token_id, workflow_id, granted_at)
             VALUES (?1, ?2, ?3)",
            params![token_id, workflow_id, now],
        )?;
        Ok(AclGrant::Granted)
    }

    /// Revoke a token's access to a specific workflow.
    ///
    /// Refuses to remove a token's only grant ([`AclRevoke::LastGrant`]):
    /// a token with no grants is unrestricted, so that would widen its access.
    /// To cut a token off, use [`revoke_token`](Self::revoke_token). The check
    /// and the delete share one write transaction, so concurrent revokes
    /// cannot both pass the check and empty the list. Writes nothing unless
    /// the result is [`AclRevoke::Revoked`].
    pub fn acl_revoke(&self, token_id: &str, workflow_id: &str) -> rusqlite::Result<AclRevoke> {
        let mut conn = self.conn.lock().unwrap_or_else(|e| e.into_inner());
        let tx = conn.transaction_with_behavior(TransactionBehavior::Immediate)?;
        let (total, target): (i64, i64) = tx.query_row(
            "SELECT COUNT(*), COALESCE(SUM(workflow_id = ?2), 0)
             FROM token_workflow_acl WHERE token_id = ?1",
            params![token_id, workflow_id],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )?;
        if target == 0 {
            return Ok(AclRevoke::NotGranted);
        }
        if total == 1 {
            return Ok(AclRevoke::LastGrant);
        }
        tx.execute(
            "DELETE FROM token_workflow_acl WHERE token_id = ?1 AND workflow_id = ?2",
            params![token_id, workflow_id],
        )?;
        tx.commit()?;
        Ok(AclRevoke::Revoked)
    }

    /// List all workflow IDs a token has been granted access to.
    /// Returns an empty Vec for a token created without grants (unrestricted).
    pub fn acl_list(&self, token_id: &str) -> rusqlite::Result<Vec<String>> {
        let conn = self.conn.lock().unwrap_or_else(|e| e.into_inner());
        let mut stmt = conn.prepare(
            "SELECT workflow_id FROM token_workflow_acl
             WHERE token_id = ?1
             ORDER BY granted_at ASC",
        )?;
        let rows = stmt.query_map(params![token_id], |row| row.get::<_, String>(0))?;
        rows.collect()
    }

    /// Determine which workflow IDs a token may access.
    ///
    /// Returns `None`  → no filter (see all workflows).
    /// Returns `Some(set)` → only those workflow IDs are visible.
    ///
    /// Rules:
    /// - Admin tokens: always unrestricted (None).
    /// - Tokens with no ACL rows (created without grants): unrestricted (None).
    /// - Tokens with ≥1 ACL row: restricted to that set (Some). Revoking the
    ///   last row is refused, so a restricted token stays restricted.
    pub fn acl_filter(&self, record: &TokenRecord) -> rusqlite::Result<Option<std::collections::HashSet<String>>> {
        if record.has_scope("admin") {
            return Ok(None);
        }
        let ids = self.acl_list(&record.token_id)?;
        if ids.is_empty() {
            Ok(None)
        } else {
            Ok(Some(ids.into_iter().collect()))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn open_temp_store() -> TokenStore {
        let dir = std::env::temp_dir().join(format!("aerini-token-store-test-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&dir).expect("create temp dir");
        TokenStore::open(&dir.join("tokens.db"), [7u8; 32]).expect("open token store")
    }

    /// All workflow_ids passed to `create_token_with_workflows` must be
    /// granted in the same call — no separate `acl_grant` needed afterward.
    #[test]
    fn create_token_with_workflows_grants_all_ids() {
        let store = open_temp_store();
        let ids = vec!["wf_a".to_string(), "wf_b".to_string()];
        let (token_id, _raw) = store
            .create_token_with_workflows("widget-reader", &["read"], None, &ids)
            .expect("create token with workflows");
        let mut granted = store.acl_list(&token_id).expect("acl_list");
        granted.sort();
        assert_eq!(granted, vec!["wf_a".to_string(), "wf_b".to_string()]);
    }

    /// A token created without workflow ids has no ACL rows (unrestricted).
    #[test]
    fn create_token_with_workflows_empty_slice_leaves_token_unrestricted() {
        let store = open_temp_store();
        let (token_id, _raw) = store
            .create_token_with_id("no-restriction", &["read"], None)
            .expect("create token");
        assert!(store.acl_list(&token_id).expect("acl_list").is_empty());
    }

    #[test]
    fn revoking_only_grant_is_refused_and_token_stays_restricted() {
        let store = open_temp_store();
        let (token_id, raw) = store
            .create_token_with_workflows("scoped", &["write"], None, &["wf_a".to_string()])
            .expect("create token with workflows");
        let record = store.verify_token(&raw).expect("verify");
        assert_eq!(store.acl_revoke(&token_id, "wf_a").expect("revoke grant"), AclRevoke::LastGrant);
        assert_eq!(store.acl_list(&token_id).expect("acl_list"), vec!["wf_a".to_string()]);
        assert!(store.acl_filter(&record).expect("filter").is_some());
    }

    #[test]
    fn revoking_one_of_two_grants_keeps_the_other() {
        let store = open_temp_store();
        let ids = vec!["wf_a".to_string(), "wf_b".to_string()];
        let (token_id, _raw) = store
            .create_token_with_workflows("scoped", &["read"], None, &ids)
            .expect("create token with workflows");
        assert_eq!(store.acl_revoke(&token_id, "wf_a").expect("revoke grant"), AclRevoke::Revoked);
        assert_eq!(store.acl_list(&token_id).expect("acl_list"), vec!["wf_b".to_string()]);
    }

    #[test]
    fn revoking_an_absent_grant_changes_nothing() {
        let store = open_temp_store();
        let (token_id, _raw) = store
            .create_token_with_workflows("scoped", &["read"], None, &["wf_a".to_string()])
            .expect("create token with workflows");
        assert_eq!(store.acl_revoke(&token_id, "wf_x").expect("revoke absent"), AclRevoke::NotGranted);
        assert_eq!(store.acl_revoke("no-such-token", "wf_a").expect("revoke unknown token"), AclRevoke::NotGranted);
        assert_eq!(store.acl_list(&token_id).expect("acl_list"), vec!["wf_a".to_string()]);
    }

    #[test]
    fn admin_token_is_unrestricted_despite_grants() {
        let store = open_temp_store();
        let (_, raw) = store
            .create_token_with_workflows("root", &["admin"], None, &["wf_a".to_string()])
            .expect("create token with workflows");
        let record = store.verify_token(&raw).expect("verify");
        assert!(store.acl_filter(&record).expect("filter").is_none());
    }

    #[test]
    fn verify_token_rejects_unparseable_expiry() {
        let store = open_temp_store();
        let raw = store.create_token("t", &["read"], Some(3600)).expect("create");
        assert!(store.verify_token(&raw).is_some());
        store.conn.lock().unwrap()
            .execute("UPDATE tokens SET expires_at = 'garbage'", [])
            .expect("corrupt expiry");
        assert!(store.verify_token(&raw).is_none());
    }

    #[test]
    fn acl_grant_refuses_unknown_and_revoked_tokens() {
        let store = open_temp_store();
        assert_eq!(store.acl_grant("no-such-token", "wf_a").expect("grant unknown"), AclGrant::NoActiveToken);
        let (token_id, _raw) = store
            .create_token_with_id("t", &["read"], None)
            .expect("create token");
        assert_eq!(store.acl_grant(&token_id, "wf_a").expect("grant active"), AclGrant::Granted);
        store.revoke_token(&token_id).expect("revoke");
        assert_eq!(store.acl_grant(&token_id, "wf_b").expect("grant revoked"), AclGrant::NoActiveToken);
        assert!(store.acl_list(&token_id).expect("acl_list").is_empty());
    }

    #[test]
    fn acl_grant_refuses_admin_tokens_and_writes_nothing() {
        let store = open_temp_store();
        let (token_id, _raw) = store
            .create_token_with_id("root", &["read", "admin"], None)
            .expect("create admin token");
        assert_eq!(store.acl_grant(&token_id, "wf_a").expect("grant admin"), AclGrant::AdminToken);
        assert!(store.acl_list(&token_id).expect("acl_list").is_empty());
    }

    #[test]
    fn revoke_token_reports_whether_the_token_exists() {
        let store = open_temp_store();
        let (token_id, raw) = store
            .create_token_with_id("t", &["read"], None)
            .expect("create token");
        assert!(store.revoke_token(&token_id).expect("first revoke"));
        assert!(store.revoke_token(&token_id).expect("repeat revoke"));
        assert!(store.verify_token(&raw).is_none());
        assert!(!store.revoke_token("no-such-token").expect("unknown revoke"));
    }
}
