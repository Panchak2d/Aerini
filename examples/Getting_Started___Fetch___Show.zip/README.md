# Flowo Docker Deployment

**Workflow:** Getting Started — Fetch & Show  
**Trigger:** Every 10 seconds

## Quick Start

```bash
# 1. Fill in credentials
cp .env.example .env
$EDITOR .env

# 2. Build and start
docker compose up --build -d

# 3. View status page
open http://localhost:7700

# 4. Follow logs
docker compose logs -f flowo-Getting_Started___Fetch___Show
```


## Security

`flowo-server.json` in this example has `run_secret: null`, which means:

- The status page (`/api/status`, `/api/logs`, `/api/runs`) is publicly accessible
  to anyone who can reach port 7700 — run history and timing data are visible.
- The Run Now trigger (`/api/run`) is disabled.

**Before exposing this container publicly**, set a run secret:

1. Generate a secret: `openssl rand -hex 16`
2. Compute its BLAKE3 hash and put the hash (not the raw value) in `flowo-server.json` as `run_secret`.
   Or re-export the workflow from Flowo Desktop — the app handles hashing automatically.
3. Store the raw secret somewhere safe (password manager). The status page will require it
   as `Authorization: Bearer <raw-secret>` on authenticated endpoints.

## Credentials

This workflow uses no credentials.

Credentials are read from environment variables — they are never stored in
`flowo-server.json`. Set them in `.env` before starting the container.

## Requirements

- Docker Engine 20.10+ with Compose V2 (`docker compose`)
- Internet access during `docker compose build` (clones Flowo source)
- Node.js is **not** required on the host — it runs inside the container

## Updating the Workflow

1. Edit the workflow in Flowo Desktop.
2. Click Export → Export for Server → Docker → Generate Package.
3. Replace `flowo-server.json` with the new file from the zip.
4. Restart: `docker compose restart flowo-Getting_Started___Fetch___Show`

No rebuild required for workflow-only changes — `flowo-server.json` is mounted
read-only and reloaded on restart.

## Customising the Docker Build

By default the `Dockerfile` clones Flowo from the official repository at `main`.
To pin a specific release or use a fork:

```bash
docker compose build \
--build-arg FLOWO_REF=v0.2.0 \
--build-arg FLOWO_REPO=https://github.com/your-org/flowo
```

## Port Mapping

The status page is bound to `127.0.0.1:7700` by default (localhost only).
To expose it publicly, edit `docker-compose.yml`:
```yaml
ports:
- "0.0.0.0:7700:7700"   # expose on all interfaces
```
Use a reverse proxy (Caddy, Nginx) with TLS for public-facing deployments.

## Shell Command and Code Nodes

Shell Command and Code nodes execute inside the container with the privileges
of the `flowo` user. The container has no elevated capabilities.
