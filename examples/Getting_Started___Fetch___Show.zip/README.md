# Aerini Docker Deployment

**Workflow:** Getting Started — Fetch & Show  
**Trigger:** Every 10 seconds

## Security Warning

`aerini-server.json` contains the argon2id hash of your `run_secret`. The raw secret was shown once at export time and is not stored in this file. Treat this zip like a credentials file: do not commit it to version
control, do not share it over unencrypted channels, and do not store
it in a world-readable directory.

## Quick Start

```bash
# 1. Fill in credentials
cp .env.example .env
$EDITOR .env

# 2. Build and start
docker compose up --build -d

# 3. View status page
open http://localhost:7700

# 4. Follow logs
docker compose logs -f aerini-Getting_Started___Fetch___Show
```

## Credentials

This workflow uses no credentials.

Credentials are read from environment variables — they are never stored in
`aerini-server.json`. Set them in `.env` before starting the container.

## Requirements

- Docker Engine 20.10+ with Compose V2 (`docker compose`)
- Internet access during `docker compose build` (clones Aerini source)
- Node.js is **not** required on the host — it runs inside the container

## Updating the Workflow

1. Edit the workflow in Aerini Desktop.
2. Click Export → Export for Server → Docker → Generate Package.
3. Replace `aerini-server.json` with the new file from the zip.
4. Restart: `docker compose restart aerini-Getting_Started___Fetch___Show`

No rebuild required for workflow-only changes — `aerini-server.json` is mounted
read-only and reloaded on restart.

## Customising the Docker Build

By default the `Dockerfile` clones Aerini from the official repository at `main`.
To pin a specific release or use a fork:

```bash
docker compose build \
  --build-arg AERINI_REF=v0.4.0 \
  --build-arg AERINI_REPO=https://github.com/Panchak2d/aerini
```

## Port Mapping

The status page is restricted to localhost via `docker-compose.yml` (`127.0.0.1:7700:7700`).
Always deploy with `docker compose up` — this is the only supported launch method.

**If you must use `docker run` directly**, always include the `127.0.0.1` host prefix:
```bash
docker run -p 127.0.0.1:7700:7700 ...   # safe: localhost only
# NOT: docker run -p 7700:7700 ...       # unsafe: exposes on all interfaces
```

To expose the status page publicly, edit `docker-compose.yml`:
```yaml
ports:
  - "0.0.0.0:7700:7700"   # expose on all interfaces
```
Use a reverse proxy (Caddy, Nginx) with TLS for public-facing deployments.

## Dangerous Node Types (Shell Command, Code, Database)

This workflow does not use any node type from the dangerous list below — nothing to enable.

| Node type | Flag | Risk |
|---|---|---|
| Shell Command | `--allow-shell` | Executes arbitrary OS commands as the container's `aerini` user (no elevated capabilities, but full command execution within the container). |
| Code (JS) | `--allow-code` | Spawns a Node.js subprocess as the container's `aerini` user. |
| Database | `--allow-database` | Connects to PostgreSQL/MySQL/SQLite/Redis; SSRF surface and RUSTSEC-2023-0071 (RSA timing side-channel in sqlx-mysql). |
